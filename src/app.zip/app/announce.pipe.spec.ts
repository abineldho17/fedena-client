import { AnnouncePipe } from './announce.pipe';

describe('AnnouncePipe', () => {
  it('create an instance', () => {
    const pipe = new AnnouncePipe();
    expect(pipe).toBeTruthy();
  });
});
