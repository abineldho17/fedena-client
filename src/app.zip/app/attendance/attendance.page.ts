import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Attendance } from 'src/providers/attendance';



@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.page.html',
  styleUrls: ['./attendance.page.scss'],
})
export class AttendancePage implements OnInit {
  full_detail = [];
  batch_detail = [];
  subjects_detail = [];
  batches: string;
  subjects: string;
  subjectAPI= '';
  //  api_url ="https://fconnect.fedena.org/api/";
  ;
  constructor(private http: HttpClient, private attendanceService: Attendance) { }

  ngOnInit() {
    
  }
  customCourse: any = {
    header: 'Course',
    
  };

  customBatch: any = {
    header: 'Batch',
    
  };

  customSubjects: any = {
    header: 'Subjects',
   
  };
  getCourse() {
    this.attendanceService.getCourse().subscribe(
   
      (res: any) => {


        if (res.courses && res.courses != null) {

          console.log(this.full_detail);
          for (let courses of res.courses) {

          
            this.full_detail.push(courses);

          }

        }

      }, error => {
        console.log(error);
      })
  }



  selectedCourse(course) {

    let courseAPI = course.target.value
     window.localStorage.setItem("course_id", course.target.value);
    this.batches = '';
    this.subjects = '';
    this.batch_detail = [];
    
    this.attendanceService. getBatches().subscribe(
      (res: any) => {


        if (res.batches && res.batches != null) {

          console.log(this.batch_detail);
          for (let batches of res.batches) {


            this.batch_detail.push(batches);


          }

        }


      }, error => {
        console.log(error);
      })

  }


  selectedBatch(batches) {
    
    this.subjectAPI = batches.target.value
     window.localStorage.setItem("batch_id", batches.target.value);
    this.subjects = '';

  }


  getSubjects() {
   
    this.subjects_detail = [];
    
    this.attendanceService. getSubjects().subscribe(
      (res: any) => {

       
        if (res.subjects && res.subjects != null) {
          // console.log(this.isEnabled);
          // if (this.subjects_detail.length==0){

          //   this.isEnabled = 'true';
          //   console.log(this.isEnabled);
          //   }
          //   else {
          //     this.isEnabled = 'false';
          //   }
          console.log(this.subjects_detail);
          console.log(this.subjects_detail.length);
          for (let subjects of res.subjects) {

            // console.log(courses);
            //  console.log(courses.id);

            this.subjects_detail.push(subjects);
            console.log(subjects.name);


          }


          // this.batch_detail.push(res.batches );

          //console.log(this.batch_detail.batch_name);

        }





      }, error => {
        console.log(error);
      })




  }

  onChange(deviceValue) {
    console.log(deviceValue);
  }
}

