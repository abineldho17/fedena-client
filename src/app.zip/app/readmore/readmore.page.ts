import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-readmore',
  templateUrl: './readmore.page.html',
  styleUrls: ['./readmore.page.scss'],
})
export class ReadmorePage implements OnInit {
  full_detail = [];
  constructor(private http: HttpClient) { 
    
  }

  ngOnInit() {

          console.log(window.localStorage.getItem("id"));
    this.http.get("http://fconnect.t.foradian.org/api/news/"+ window.localStorage.getItem("id") +".json"  ).subscribe(
      (res: any) => {
    

        if (res.news && res.news != null) {
        
          
        
          
            this.full_detail.push(res.news);
            
           
          }
         
          console.log(this.full_detail);
       
       

      }, error => {
        console.log(error);
      })
  }
  
  

}
